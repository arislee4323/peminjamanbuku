<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row justify-content-center">
		<div class="col-md-8">
			<div class="card">
				<div class="card-header">Buat Transaksi Baru </div>
				<div class="card-body">
					<form action="<?php echo e(url('/transaksi/new')); ?>" method="post">
						<?php echo e(csrf_field()); ?>

						<div class="form-group">
							<label>pelanggan</label>
							<input type="text" name="pelanggan" class="form-control">
						</div>
						<div class="form-group">
							<label>Buku</label>
								<select name="buku">
								<option>Silahakan Pilih Buku</option>
									<?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($buku->judul); ?>"><?php echo e($buku->judul); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>

						</div>
						<div class="form-group">
							<label>Tanggal Peminjaman</label>
							<input type="date" name="tanggal_peminjaman" class="form-control">
						</div>
						<div class="form-group">
							<label>Tanggal Pengembalian</label>
							<input type="date" name="tanggal_pengembalian" class="form-control">
						</div>
						<div class="form-group">
							<label>Total Harga</label>
							<input type="text" name="total_harga" class="form-control">
						</div>
						<button type="submit" class="btn btn-primary">Simpan</button>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Aris\peminjaman_buku\resources\views/transaksi/create.blade.php ENDPATH**/ ?>