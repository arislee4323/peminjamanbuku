<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row justify-content-center">
		<div class="col-md-8">
			<div class="card">
				<div class="card-header">pelanggan</div>

				<div class="card-body">
					<a href="/pelanggan/new" class="btn btn-primary">Buat Pelanggan Baru</a>
					<table class="table table-striped">
						<tr>
							<th>id</th>
							<th>nama</th>
							<th>alamat</th>
							<th>Action</th>
						</tr>
						<?php $__currentLoopData = $pelanggans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelanggan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($pelanggan->id); ?></td>
							<td><?php echo e($pelanggan->nama); ?></td>
							<td><?php echo e($pelanggan->alamat); ?></td>
							<td>
								<a href="/pelanggan/edit/<?php echo e($pelanggan-> id); ?>"><button type="submit" class="btn btn-primary btn-sm">edit</button></a>
								<form action="/pelanggan/delete/<?php echo e($pelanggan->id); ?>" method="post">
								<?php echo e(csrf_field()); ?>	
								<?php echo e(method_field('DELETE')); ?>

								<button type="submit" class="btn btn-danger btn-sm">Hapus</button>
								</form>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				      </table>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\peminjaman_buku\resources\views/pelanggan/index.blade.php ENDPATH**/ ?>