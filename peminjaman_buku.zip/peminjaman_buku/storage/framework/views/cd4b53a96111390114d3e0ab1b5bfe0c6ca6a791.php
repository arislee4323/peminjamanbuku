<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row justify-content-center">
		<div class="col-md-8">
			<div class="card">
				<div class="card-header">BUKU</div>
				<div class="card-body">
					<a href="/buku/new" class="btn btn-primary">Buat Peminjaman Buku</a>
					<table class="table table-striped">
						<tr>
							<th>id</th>
							<th>judul</th>
							<th>penulis</th>
							<th>harga_harian</th>
							<th>Action</th>
						</tr>
						<?php $__currentLoopData = $bukus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($buku->id); ?></td>
							<td><?php echo e($buku->judul); ?></td>
							<td><?php echo e($buku->penulis); ?></td>
							<td><?php echo e($buku->harga_harian); ?></td>
							<td>
								<a href="/buku/edit/<?php echo e($buku-> id); ?>"><button type="submit" class="btn btn-primary btn-sm">edit</button></a>
								<form action="/buku/delete/<?php echo e($buku->id); ?>" method="post">
									<?php echo e(csrf_field()); ?>

									<?php echo e(method_field('DELETE')); ?>

									<button type="submit" class="btn btn-danger btn-sm">Hapus</button>
								</form>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\peminjaman_buku\resources\views/buku/index.blade.php ENDPATH**/ ?>