<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row justify-content-center">
		<div class="col-md-8">
			<div class="card">
				<div class="card-header">Transaksi</div>

				<div class="card-body">
					<a href="/transaksi/new" class="btn btn-primary">Buat Transaksi Baru</a>
					<table class="table table-striped">
						<tr>
							<th>id</th>
							<th>Pelangan</th>
							<th>Buku</th>
							<th>Tanggal Peminjaman</th>
							<th>Tanggal Pengembalian</th>
							<th>Total Harga</th>
							<th>Action</th>
						</tr>
						<?php $__currentLoopData = $transaksis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($transaksi->id); ?></td>
							<td><?php echo e($transaksi->pelanggan); ?></td>
							<td><?php echo e($transaksi->buku); ?></td>
							<td><?php echo e($transaksi->tanggal_peminjaman); ?></td>
							<td><?php echo e($transaksi->tanggal_pengembalian); ?></td>
							<td><?php echo e($transaksi->total_harga); ?></td>
							
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				      </table>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Aris\peminjaman_buku\resources\views/transaksi/index.blade.php ENDPATH**/ ?>