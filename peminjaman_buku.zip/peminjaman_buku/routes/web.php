<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
   
});
  
Auth::routes();
Route::get('/home', 'HomeController@index')->name('home');

Route::get('/buku','bukucontroller@index');
Route::get('/buku/new','bukucontroller@create');
Route::post('/buku/new','bukucontroller@store');
Route::get('/buku/edit/{id}', 'bukucontroller@edit');
Route::post('/buku/edit/{id}', 'bukucontroller@update');
Route::delete('/buku/delete/{id}', 'bukucontroller@destroy');

Route::get('/pelanggan','pelanggancontroller@index');
Route::get('/pelanggan/new','pelanggancontroller@create');
Route::post('/pelanggan/new', 'pelanggancontroller@store');
Route::get('/pelanggan/edit/{id}','pelanggancontroller@edit');
Route::post('/pelanggan/edit/{id}','pelanggancontroller@update');
Route::delete('/pelanggan/delete/{id}','pelanggancontroller@destroy');
Route::get('/transaksi','transaksicontroller@index');
Route::get('/transaksi/new','transaksicontroller@create');
Route::post('/transaksi/new','transaksicontroller@store');