<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class buku extends Model
{
   public function transaksi(){
    	return $this->hasManu('App\transaksi');
    }
}
