<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class transaksi extends Model
{
    //
	public function buku(){
    	return $this->belongsTo('App\buku');
    }
}
