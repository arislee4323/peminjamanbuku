<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\transaksi;
use App\buku;

class transaksicontroller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $buku= buku::all();
        $transaksis = transaksi::all();
        return view('transaksi.index', compact('transaksis'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $buku = buku::all();
        return view('transaksi.create', compact('buku'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $buku = buku::all();
        $transaksi = new transaksi();
        $request->validate([
          'pelanggan' => 'required',
          'buku' => 'required',
          'tanggal_peminjaman' => 'required',
           'tanggal_pengembalian' =>'required',
           'total_harga' =>'required'
        ]);

        $transaksi->pelanggan = $request->pelanggan;
        $transaksi->buku = $request->buku;
        $transaksi->tanggal_peminjaman = $request->tanggal_peminjaman;
        $transaksi->tanggal_pengembalian = $request->tanggal_pengembalian;
        $transaksi->total_harga = $request->total_harga;

        $transaksi->save();
        
        return redirect('transaksi');
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
