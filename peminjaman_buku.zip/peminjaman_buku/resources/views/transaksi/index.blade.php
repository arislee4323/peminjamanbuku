@extends('layouts.app')

@section('content')
<div class="container">
	<div class="row justify-content-center">
		<div class="col-md-8">
			<div class="card">
				<div class="card-header">Transaksi</div>

				<div class="card-body">
					<a href="/transaksi/new" class="btn btn-primary">Buat Transaksi Baru</a>
					<table class="table table-striped">
						<tr>
							<th>id</th>
							<th>Pelangan</th>
							<th>Buku</th>
							<th>Tanggal Peminjaman</th>
							<th>Tanggal Pengembalian</th>
							<th>Total Harga</th>
							<th>Action</th>
						</tr>
						@foreach($transaksis as $transaksi)
						<tr>
							<td>{{ $transaksi->id }}</td>
							<td>{{ $transaksi->pelanggan}}</td>
							<td>{{ $transaksi->buku }}</td>
							<td>{{ $transaksi->tanggal_peminjaman}}</td>
							<td>{{ $transaksi->tanggal_pengembalian}}</td>
							<td>{{ $transaksi->total_harga}}</td>
							
						</tr>
						@endforeach
				      </table>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection