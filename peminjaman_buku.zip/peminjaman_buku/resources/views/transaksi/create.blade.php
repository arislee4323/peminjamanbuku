@extends('layouts.app')

@section('content')
<div class="container">
	<div class="row justify-content-center">
		<div class="col-md-8">
			<div class="card">
				<div class="card-header">Buat Transaksi Baru </div>
				<div class="card-body">
					<form action="{{ url('/transaksi/new') }}" method="post">
						{{ csrf_field() }}
						<div class="form-group">
							<label>pelanggan</label>
							<input type="text" name="pelanggan" class="form-control">
						</div>
						<div class="form-group">
							<label>Buku</label>
								<select name="buku">
								<option>Silahakan Pilih Buku</option>
									@foreach($buku as $buku)
									<option value="{{$buku->judul}}">{{$buku->judul}}</option>
									@endforeach
								</select>

						</div>
						<div class="form-group">
							<label>Tanggal Peminjaman</label>
							<input type="date" name="tanggal_peminjaman" class="form-control">
						</div>
						<div class="form-group">
							<label>Tanggal Pengembalian</label>
							<input type="date" name="tanggal_pengembalian" class="form-control">
						</div>
						<div class="form-group">
							<label>Total Harga</label>
							<input type="text" name="total_harga" class="form-control">
						</div>
						<button type="submit" class="btn btn-primary">Simpan</button>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection