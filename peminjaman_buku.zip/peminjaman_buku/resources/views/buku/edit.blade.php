@extends('layouts.app')

@section('content')
<div class="container">
	<div class="row justify-content-center">
		<div class="col-md-8">
			<div class="card">
				<div class="card-header">EDIT BUKU</div>
				<div class="card-body">
					<form action="{{ url('/buku/edit/' . $buku->id) }}" method="post">
						{{ csrf_field() }}
						<div class="form-group">
							<label>Judul</label>
							<input type="text" name="judul" value="{{$buku->judul}}" class="form-control">
						</div>
						<div class="form-group">
							<label>Penulis</label>
							<input type="text" name="penulis" value="{{$buku->penulis}}" class="form-control">
						</div>
						<div class="form-group">
							<label>Harga Harian</label>
							<input type="text" name="harga_harian" value="{{$buku->harga_harian}}" class="form-control">
						</div>
						<button type="submit" class="btn btn-primary">Simpan</button>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection