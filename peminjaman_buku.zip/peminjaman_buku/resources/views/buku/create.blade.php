@extends('layouts.app')

@section('content')
<div class="container">
	<div class="row justify-content-center">
		<div class="col-md-8">
			<div class="card">
				<div class="card-header">Buat peminjaman Baru</div>
				<div class="card-body">
					<form action="{{ url('/buku/new') }}" method="post">
						{{ csrf_field() }}
						<div class="form-group">
							<label>judul</label>
							<input type="text" name="judul" class="form-control">
						</div>
						<div class="form-group">
							<label>penulis</label>
							<input type="text" name="penulis" class="form-control">
						</div>
						<div class="form-group">
							<label>Harga Harian</label>
							<input type="text" name="harga_harian" class="form-control">
						</div>
						<button type="submit" class="btn btn-primary">Simpan</button>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection