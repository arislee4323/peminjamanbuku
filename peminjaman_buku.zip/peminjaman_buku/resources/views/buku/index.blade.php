@extends('layouts.app')

@section('content')
<div class="container">
	<div class="row justify-content-center">
		<div class="col-md-8">
			<div class="card">
				<div class="card-header">BUKU</div>
				<div class="card-body">
					<a href="/buku/new" class="btn btn-primary">Buat Peminjaman Buku</a>
					<table class="table table-striped">
						<tr>
							<th>id</th>
							<th>judul</th>
							<th>penulis</th>
							<th>harga_harian</th>
							<th>Action</th>
						</tr>
						@foreach($bukus as $buku)
						<tr>
							<td>{{ $buku->id }}</td>
							<td>{{ $buku->judul}}</td>
							<td>{{$buku->penulis}}</td>
							<td>{{ $buku->harga_harian}}</td>
							<td>
								<a href="/buku/edit/{{ $buku-> id}}"><button type="submit" class="btn btn-primary btn-sm">edit</button></a>
								<form action="/buku/delete/{{$buku->id}}" method="post">
									{{ csrf_field() }}
									{{method_field('DELETE') }}
									<button type="submit" class="btn btn-danger btn-sm">Hapus</button>
								</form>
							</td>
						</tr>
						@endforeach
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection