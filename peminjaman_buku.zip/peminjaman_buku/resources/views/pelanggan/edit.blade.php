@extends('layouts.app')

@section('content')
<div class="container">
	<div class="row justify-content-center">
		<div class="col-md-8">
			<div class="card">
				<div class="card-header">EDIT BUKU</div>
				<div class="card-body">
					<form action="{{ url('/pelanggan/edit/' . $pelanggan->id) }}" method="post">
						{{ csrf_field() }}
						<div class="form-group">
							<label>Nama</label>
							<input type="text" name="nama" value="{{$pelanggan->nama}}" class="form-control">
						</div>
						<div class="form-group">
							<label>Alamat</label>
							<input type="text" name="alamat" value="{{$pelanggan->alamat}}" class="form-control">
						</div>
						<button type="submit" class="btn btn-primary">Simpan</button>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection