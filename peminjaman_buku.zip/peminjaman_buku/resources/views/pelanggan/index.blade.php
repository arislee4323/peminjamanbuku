@extends('layouts.app')

@section('content')
<div class="container">
	<div class="row justify-content-center">
		<div class="col-md-8">
			<div class="card">
				<div class="card-header">pelanggan</div>

				<div class="card-body">
					<a href="/pelanggan/new" class="btn btn-primary">Buat Pelanggan Baru</a>
					<table class="table table-striped">
						<tr>
							<th>id</th>
							<th>nama</th>
							<th>alamat</th>
							<th>Action</th>
						</tr>
						@foreach($pelanggans as $pelanggan)
						<tr>
							<td>{{ $pelanggan->id }}</td>
							<td>{{ $pelanggan->nama}}</td>
							<td>{{ $pelanggan->alamat}}</td>
							<td>
								<a href="/pelanggan/edit/{{ $pelanggan-> id}}"><button type="submit" class="btn btn-primary btn-sm">edit</button></a>
								<form action="/pelanggan/delete/{{$pelanggan->id}}" method="post">
								{{ csrf_field() }}	
								{{ method_field('DELETE') }}
								<button type="submit" class="btn btn-danger btn-sm">Hapus</button>
								</form>
							</td>
						</tr>
						@endforeach
				      </table>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection